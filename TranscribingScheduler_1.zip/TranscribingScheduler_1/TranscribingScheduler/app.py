import streamlit as st
from datetime import datetime, date, time as dtime, timedelta
import time
from scheduler import Scheduler

def run_main(schedule_time):
    
    scheduler_obj = Scheduler()
    val = scheduler_obj.start_scheduling(schedule_time)

    if val:
    
        return "Job Completed Successfully!"

# Set up a clean page layout and title.
st.set_page_config(page_title="Scheduled Task Runner", page_icon="⏰")
st.title("⏰ Scheduled Task Runner")
st.markdown("Select a time from the list below and click **Start Task**. The app will wait until the scheduled time and then execute the task.")

# List of pre-defined scheduled times.
time_options = ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:44', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00']

# Display the list of times using a selectbox for a clean UI.
selected_time_str = st.selectbox("Select a scheduled time:", time_options)
st.write(f"You have selected: **{selected_time_str}**")

if st.button("Start Task"):
    now = datetime.now()

    # Parse the selected time string into a time object.
    hours, minutes = map(int, selected_time_str.split(":"))
    scheduled_datetime = datetime.combine(date.today(), dtime(hours, minutes))
    
    # If the scheduled time for today has already passed, schedule it for tomorrow.
    # if now >= scheduled_datetime:
    #     st.info("The selected time has already passed for today. Scheduling for tomorrow.")
    #     scheduled_datetime += timedelta(days=1)
    
    # wait_seconds = (scheduled_datetime - now).total_seconds()
    # st.write(f"Waiting for {int(wait_seconds)} seconds until {scheduled_datetime.strftime('%Y-%m-%d %H:%M:%S')}...")
    
    # Blocking wait until the scheduled time.
    # time.sleep(wait_seconds)
    
    # Run your main function at the scheduled time.

    start_time = f"{hours}:{minutes}"
    result = run_main(start_time)
    st.success(result)
    st.write("Finished")
