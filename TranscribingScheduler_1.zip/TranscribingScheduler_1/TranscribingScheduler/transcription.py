from pathlib import Path
import os
import whisper
import concurrent.futures
from datetime import datetime
from multiprocessing import Process , Queue
from rdascript import Database
from concurrent.futures import ProcessPoolExecutor
import time
import requests
import torch


class TranscribeAudio:

    def __init__(self):
        pass

    def transcribe_wrapper(self,path):

        super_list = []

        # device = "cuda" if torch.cuda.is_available() else "cpu"

        model = whisper.load_model("base")

        # if device == "cuda":
        #     model = model.half()
        
        for p in path:
              # Load inside the thread

            audio_name = p.split("\\")[5]
            #audio_name = audio_name.split("_")[0]
            audio_name = audio_name + ".mp3"

            chunk_name = p.split("\\")[6]

            db_obj = Database()
            #audio_id = db_obj.get_audio_id(audio_name)
            audio_id = db_obj.get_audio_id(audio_name)


            result = model.transcribe(p)


            segments = result["segments"]


            chunk_creation_date = datetime.now().date()
            chunk_creation_date_time = datetime.now()

            chunk_time_stamps = ""
            chunk_text = ""
            previous_end_time = 0  # ← You had this missing in the original

            for segment in segments:
                start_time = segment['start'] + previous_end_time
                end_time = segment['end'] + previous_end_time
                chunk_time_stamps += f" {start_time} - {end_time} $!"
                chunk_text += f"{segment['text']} $!"

            
            chunk_details = {
                'chunk_file_name': f"{audio_name} / {chunk_name}",
                'chunk_text': chunk_text,
                #'timestamps': chunk_time_stamps,
                'audio_id': audio_id,
                #'chunk_creation_date': chunk_creation_date,
                #'chunk_creation_date_time': chunk_creation_date_time
            }



            save_transcription = SaveTranscription()

            save_transcription.save_transcription(chunk_details)

            # url = "https://expenseapp.creowiz.com/api/get_audio_data/"

            # resp = requests.post(url , data = chunk_details)

            # print(resp.status_code)

            super_list.append(chunk_details)





class SaveTranscription:

    def __init__(self):
        pass

    def save_transcription(self , chunk_details):
        
        try:
            url = "https://expenseapp.creowiz.com/api/get_audio_data/"

            resp = requests.post(url , data = chunk_details)

            print(resp.status_code)

        except Exception as error:
            return str(error)


class GetAudioPath:

    def __init__(self):
        pass


    def get_audio_chunks_path(self)-> list[list]: 

        chunks = Path("C:\\Users\\mohammad.adeeb\\ChunkingScheduler\\Chunks")

        chunk_list = []

        for i in os.listdir(chunks):

            chunk_full_path = []
            full_path = os.path.join(chunks, i)

            for files in os.walk(full_path):

                for i in files[2]:

                    chunk_full_path.append(os.path.join(full_path , i))

                chunk_list.append(chunk_full_path)

        return chunk_list

# chunk_list = get_audio_chunks_path()



# print(chunk_list)


# def transcribe():
#     start = time.perf_counter()
#     for i in chunk_list:
#         for j in i:
#             transcribe_wrapper(j)
#     end = time.perf_counter()

#     print(f"Total time elapsed {end - start : .4f}")
    
# transcribe()

# def main():

#     start = time.perf_counter()
#     for i in chunk_list:
#         with ProcessPoolExecutor() as executor:
#             executor.map(transcribe_wrapper, i)
#     end = time.perf_counter()

#     print(f"Total time taken {end - start:.4f}" )
# if __name__ == '__main__':
#     main()
    
class StartProcessing:

    def __init__ (self):
        pass

    def main(self):
        audio_obj = GetAudioPath()
        chunk_list = audio_obj.get_audio_chunks_path()

        print(f"THIS IS CHUNK LIST {chunk_list}")


        transcriber_obj = TranscribeAudio()

        start = time.perf_counter()

        try:
            for i in range(0, len(chunk_list), 2):
                p1 = Process(target=transcriber_obj.transcribe_wrapper, args=(chunk_list[i],))
                #print(p1._identity)
                
                p2 = None
                if i + 1 < len(chunk_list):
                    p2 = Process(target=transcriber_obj.transcribe_wrapper, args=(chunk_list[i + 1],))

                p1.start()
                if p2: p2.start()

                p1.join()
                if p2: p2.join()
            end = time.perf_counter()

            print(f"Total time elapsed {end - start : .4f}")

            return True
        except Exception as error:
            print(f"Error {error}")
            return False