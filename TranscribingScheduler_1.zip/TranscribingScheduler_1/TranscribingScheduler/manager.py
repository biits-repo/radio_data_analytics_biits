import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from transcription import StartProcessing
from archive import archive_and_clear_chunks


class DirectoryHandler(FileSystemEventHandler):
    def on_created(self, event):
        """Handle creation events for both files and directories"""
        if event.is_directory:
            print(f"New directory created: {event.src_path}")
            # Give the system a moment to finish creating the directory
            time.sleep(1)
            self.check_for_files(event.src_path)
        else:
            # Also handle file creation events
            print(f"New file created: {event.src_path}")
            
    def on_modified(self, event):
        """Monitor for modifications which can happen when files are added to directories"""
        if event.is_directory:
            # When a directory is modified (files added/removed)
            self.check_for_files(event.src_path)
    
    def check_for_files(self, directory):
        """Check contents of a directory and print files found"""
        try:
            files = os.listdir(directory)
            if files:
                print(f"Directory '{directory}' contains files: {files}")
            else:
                print(f"Directory '{directory}' is empty.")
        except (FileNotFoundError, PermissionError) as e:
            print(f"Error checking directory '{directory}': {e}")

if __name__ == "__main__":
    path_to_watch = "C:\\Users\\mohammad.adeeb\\ChunkingScheduler\\Chunks"
    
    # Ensure the directory to watch exists
    if not os.path.exists(path_to_watch):
        try:
            os.makedirs(path_to_watch)
            print(f"Created directory: {path_to_watch}")
        except Exception as e:
            print(f"Error creating directory: {e}")
            exit(1)
    
    event_handler = DirectoryHandler()
    observer = Observer()
    # Enable recursive=True to also monitor subdirectories
    observer.schedule(event_handler, path=path_to_watch, recursive=True)
    observer.start()

    print(f"Watching for new directories and files in: {path_to_watch}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Monitoring stopped by user")
        observer.stop()
    
    observer.join()

    process_obj = StartProcessing()
    process_obj.main()
    archive_and_clear_chunks()