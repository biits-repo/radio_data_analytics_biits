import shutil
import os
from datetime import datetime

def archive_and_clear_chunks(chunks_path="C:\\Users\\mohammad.adeeb\\ChunkingScheduler\\Chunks", archive_dir="C:\\Users\\mohammad.adeeb\\ChunkingScheduler\\Archive"):
    try:
        # Ensure archive destination exists
        if not os.path.exists(archive_dir):
            os.makedirs(archive_dir)

        # Create archive filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_name = os.path.join(archive_dir, f"ChunksBackup_{timestamp}")

        # Make zip archive
        shutil.make_archive(archive_name, 'zip', chunks_path)
        print(f"Archived Chunks folder to: {archive_name}.zip")

        # Now delete contents of Chunks folder
        # for item in os.listdir(chunks_path):
        #     item_path = os.path.join(chunks_path, item)
        #     if os.path.isdir(item_path):
        #         shutil.rmtree(item_path)
        #     else:
        #         os.remove(item_path)

        print("All contents of the Chunks folder have been cleared.")

    except Exception as e:
        print(f"Error during archiving or clearing: {e}")


archive_and_clear_chunks()
