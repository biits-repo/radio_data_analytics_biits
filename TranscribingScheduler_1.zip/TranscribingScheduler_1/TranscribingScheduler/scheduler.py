import schedule
import time
#from logger_manager import LoggerManager
from transcription import StartProcessing
import sys
from colorama import init, Fore, Style

init(autoreset=True)


#logger = LoggerManager.get_logger(__name__)


class Scheduler:
    def __init__(self ):
        #self.logger = logger
        pass

    def start_scheduling(self , script_start_time):
        
        self.script_start_time = script_start_time

        schedule.every().day.at(script_start_time).do(self.run_main)
        

    def run_main(self):

        process_obj = StartProcessing()
        is_true = process_obj.main()
        if is_true:
            print(Fore.GREEN + "Transcription process completed successfully")
            
            sys.exit(1)
                


if __name__ == "__main__":

    if len(sys.argv) < 2:

        print(Fore.GREEN + Style.BRIGHT + "Usage: python scheduler.py Logger <start_time> in 24 hour format e.g: 22:14 -> 10:14 PM")
        sys.exit(1)

    script_start_time = sys.argv[1]

    scheduler = Scheduler()
    scheduler.start_scheduling(script_start_time)

    
    while True:
        schedule.run_pending()
        time.sleep(1)

    #print("Scheduled job completed. Exiting.")
