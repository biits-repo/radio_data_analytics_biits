# main.py
import sys
from logger_manager import LoggerManager
from csv_saver import CsvSaver
from get_csv import AudioPathCollector
from pathlib import Path
from chunking import ThreadChunking

logger = LoggerManager.get_logger()

def main(csv_path:str , root_folder:str):
    # if len(sys.argv) < 3:
    #     logger.error("Usage: python script.py <csv_path> <root_folder>")
    #     sys.exit(1)

    #csv_path = sys.argv[1]
    #root_folder = sys.argv[2]

    csv_path = csv_path
    root_folder = root_folder

    saver = CsvSaver(logger)
    collector = AudioPathCollector(root_folder, saver, logger)

    csv_dir = Path("AudioCSV")
    csv_dir.mkdir(exist_ok=True)


    current_directory = Path.cwd()
    csv_file_path = csv_dir /  csv_path

    full_csv_path = current_directory / csv_file_path

    if collector.execute(csv_file_path):
        chunk_obj = ThreadChunking(logger)
        chunk_obj.start_thread_chunking(full_csv_path)
    else:
        logger.error("CSV generation failed.")

# if __name__ == "__main__":
#     main()
