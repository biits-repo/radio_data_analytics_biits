import subprocess
from pathlib import Path
import concurrent.futures
import pandas as pd



class Chunker:

    def __init__(self,logger):

        self.logger = logger

    def chunk_audio(self , audio_file):

        audio_file = str(audio_file)
        base_chunk_dir = Path("Chunks")
        base_chunk_dir.mkdir(exist_ok=True)
        
        file_stem = Path(audio_file).stem
        chunk_dir = base_chunk_dir / f"{file_stem}"
        chunk_dir.mkdir(exist_ok=True)
    
        self.chunk_path = chunk_dir / 'chunk_%d.mp3'

        command = [
            'ffmpeg',
            '-i', audio_file,
            '-f', 'segment',
            '-segment_time', str(200),
            '-c:a', 'libmp3lame',
            '-b:a', '192k',
            self.chunk_path
            #self.chunk_path
        ]

        try:
            subprocess.run(command, check=True)
            self.logger.info(f"Audio file '{audio_file}' has been chunked successfully.")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.info(f"An error occurred while chunking the audio file: {e}")
            return False
        

class ThreadChunking:

    def __init__(self,logger):
        
        self.logger = logger
        self.chunk_obj = Chunker(self.logger)
        

    def start_thread_chunking(self,path_list):
        
        df = pd.read_csv(path_list)
        path_list = df["full_path"]
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            try:
                future_to_path = {executor.submit(self.chunk_obj.chunk_audio, path): path for path in path_list}
                for future in concurrent.futures.as_completed(future_to_path):
                    path = future_to_path[future]
                    future.result()
            except Exception as exc:
                self.logger.error(f"Audio file generated an exception: {exc}")