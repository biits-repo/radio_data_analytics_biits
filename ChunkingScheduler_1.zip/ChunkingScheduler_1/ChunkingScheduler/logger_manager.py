import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import __main__

class LoggerManager:
    @staticmethod
    def get_logger(name=None, level=logging.INFO):
        # If logger is called from a script (not a module), use actual filename
        if name is None or name == "__main__":
            name = Path(__main__.__file__).stem  # eg for recalling , main.py → "main"

        # Defininig log file path using script/module name
        log_path = Path("logs") / f"{name}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)  # Ensuring logs/ exists

        logger = logging.getLogger(name)
        logger.setLevel(level)
        logger.propagate = False  # It will Prevent duplicate logs

        if not logger.handlers:  # Avoid adding handlers multiple times
            formatter = logging.Formatter(
                "%(asctime)s — %(name)s — %(levelname)s — %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )

            # Console output
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)

            # File output with rotation (1MB max, keep 5 backups)
            file_handler = RotatingFileHandler(
                log_path, maxBytes=1_000_000, backupCount=5
            )
            file_handler.setFormatter(formatter)

            # Add handlers to the logger
            logger.addHandler(console_handler)
            logger.addHandler(file_handler)

        return logger
