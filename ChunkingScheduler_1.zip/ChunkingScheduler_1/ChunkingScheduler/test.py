import os
from pathlib import Path

from rdascript import Database



# print(Path.cwd() / "AudioCSV")


# #Updates 

# # 1 . Logger Switch 
# # 2 . Remove chunk after transcribing and put in archive folder

audio_data = [
    {'audio_name': 'invideo-ai-1080.mp3', 'audi_length': '0:4:47'},
    {'audio_name': 'recordings_F1-1.mp3', 'audi_length': '0:0:15'},
    {'audio_name': 'recordings_F1-2.mp3', 'audi_length': '0:0:15'},
    {'audio_name': 'recordings_F1-3.mp3', 'audi_length': '0:0:15'},
    {'audio_name': 'recordings_F2-1.mp3', 'audi_length': '0:0:15'},
    {'audio_name': 'recordings_F2-2.mp3', 'audi_length': '0:0:15'},
    {'audio_name': 'recordings_F2-3.mp3', 'audi_length': '0:0:15'}
]

db_obj = Database()
db_obj.store_audio_data(audio_data)