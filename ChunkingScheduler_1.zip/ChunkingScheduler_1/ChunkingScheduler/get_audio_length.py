from pydub.utils import mediainfo



class GetAudioLength:

    def __init__(self,logger):

        self.logger = logger

    
    def get_audio_length(self,audio_path:list[str]) -> int:

        self.audio_length = []

        try:
            for path in audio_path:
                audio_info = mediainfo(path)
                total_seconds = float(audio_info["duration"])

                hours = int(total_seconds // 3600)
                minutes = int((total_seconds % 3600) // 60)
                seconds = total_seconds % 60

                # Print the result
                #self.audio_length = f"{hours}:{minutes}:{seconds:.0f}"
                self.audio_length.append(f"{hours}:{minutes}:{seconds:.0f}")
            return self.audio_length
        except Exception as e:
            self.logger.error(f"Error getting audio length: {str(e)}")
