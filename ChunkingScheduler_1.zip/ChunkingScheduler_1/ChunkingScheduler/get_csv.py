# get_csv.py
from pathlib import Path
from typing import List, Dict
import os
from csv_saver import CsvSaver
from get_audio_length import GetAudioLength
from rdascript import Database

class AudioPathCollector:
    def __init__(self, root_folder: str, saver: CsvSaver, logger):
        self.root_folder = Path(root_folder)
        self.saver = saver
        self.logger = logger
        self.get_audio_length = GetAudioLength(self.logger)
        self.db = Database()

    def collect_paths(self) -> Dict[str, List[str]]:


        audio_names = []
        audio_paths = []
        

        for folder in os.listdir(self.root_folder):
            folder_path = self.root_folder / folder
            if folder_path.is_dir():
                for file_name in os.listdir(folder_path):
                    file_path = folder_path / file_name
                    if file_path.is_file():
                        audio_names.append(file_name)
                        audio_paths.append(str(file_path))
                    
        audio_lengths = self.get_audio_length.get_audio_length(audio_paths)

            

        audio_data = [
                        {'audio_name': name, 'audi_length': length}
                        for name, length in zip(audio_names, audio_lengths)
                     ]
        
        self.db.store_audio_data(audio_data)

        return {
            "audio_name": audio_names,
            "full_path": audio_paths,
            "audio_length": audio_lengths
        }

    def execute(self, csv_path: str) -> bool:
        
        try:
            data = self.collect_paths()
            return self.saver.save(data, csv_path)
        except Exception as e:
            self.logger.error(f"Error while collecting/saving paths: {e}")
            return False
