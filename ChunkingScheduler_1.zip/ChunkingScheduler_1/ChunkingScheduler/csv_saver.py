# csv_saver.py
import pandas as pd
from typing import Dict, List
import logging
from pathlib import Path
import os

class CsvSaver:
    def __init__(self, logger: logging.Logger):
        self.logger = logger

    def save(self, data: Dict[str, List[str]], csv_path: str) -> bool:
        
        try:
            
            df = pd.DataFrame(data)
            df.to_csv(csv_path, index=False)
            self.logger.info(f"CSV saved successfully at {csv_path}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to save CSV: {e}")
            return False

